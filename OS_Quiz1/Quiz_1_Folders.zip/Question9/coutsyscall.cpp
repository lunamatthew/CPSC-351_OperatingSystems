#include <iostream>

int main() {
	
	std::cout << "What syscall do I use?\n";

	return 0;
}
